/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entidad.Cliente;
import DAO.Conexion_DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lliurex
 */
public class Cliente_DAO {
    
    public void actualiza(Connection con, Cliente cliente) throws Exception{
        PreparedStatement stmt=null;
        
        try {       
            stmt = con.prepareStatement("UPDATE cliente SET Nombre=?, Ape1=?,"+
                    "Ape2=?, Nick=?, Passwd=?, Saldo=?, Moroso=? WHERE DNI=?");
            stmt.setInt(1, cliente.getDNI());
            stmt.setString(2, cliente.getNombre());
            System.out.println("nombre cliente"+ cliente.getNombre());
            stmt.setString(3, cliente.getApellido1());
            stmt.setString(4, cliente.getApellido2());
            stmt.setString(5, cliente.getNick());
            stmt.setString(6, cliente.getPassword());
            stmt.setFloat(7, cliente.getSaldo());

            if(cliente.isMoroso()){
                stmt.setInt(8, 1);            
            }
            else{
                stmt.setInt(8, 0);
            }            
            stmt.executeUpdate();
        
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw  new Exception("Problemas al actualizar cliente "+ex.getMessage());
        } finally
        {
            if(stmt!=null){
                stmt.close();
            }
        }
    }    
    public void elimina(Connection con, Cliente cliente) throws Exception{
        PreparedStatement stmt=null;
        
        try{
           stmt=con.prepareStatement("DELETE FROM cliente WHERE DNI=?");
           stmt.setInt(1, cliente.getDNI());
           stmt.executeUpdate();
           
        } catch (SQLException ex){
            ex.printStackTrace();
            throw new Exception("problemas al insertar el cliente "+ex.getMessage());
        } finally
        {
           if(stmt!=null){
                stmt.close();
            }
        } 
    }
    public void inserta(Connection con, Cliente cliente) throws Exception{
        PreparedStatement stmt=null;
        
        try{
            stmt=con.prepareStatement("INSERT INTO Cliente (DNI, Nombre,Ape1,Ape2,Nick,"+
                    "Passwd,Saldo,Moroso) VALUES(?,?,?,?,?,?,?,?)");
            stmt.setInt(1,cliente.getDNI());
            stmt.setString(2, cliente.getNombre());
            stmt.setString(3, cliente.getApellido1());
            stmt.setString(4, cliente.getApellido2());
            stmt.setString(5, cliente.getNick());
            stmt.setString(6, cliente.getPassword());
            stmt.setFloat(7, cliente.getSaldo());
            if(cliente.isMoroso()){
                stmt.setInt(8, 1);            
            }
            else{
                stmt.setInt(8, 0);
            }            
            stmt.executeUpdate();
        
        } catch (SQLException ex){
            ex.printStackTrace();
            throw new Exception("problemas al insertar cliente "+ex.getMessage());
        } finally
        {
           if(stmt!=null){
                stmt.close();
            }
        }
    }
    
    private void obtenClienteFila(ResultSet rs, Cliente cliente) throws Exception{
        
        cliente.setDNI(rs.getInt("DNI"));
        cliente.setNombre(rs.getString("Nombre"));
        cliente.setApellido1(rs.getString("Ape1"));
        cliente.setApellido2(rs.getString("Ape2"));
        cliente.setNick(rs.getString("Nick"));
        cliente.setPassword(rs.getString("Passwd"));
        cliente.setSaldo(rs.getFloat("Saldo"));        
            if(rs.getInt("Moroso")==0){
                cliente.setMoroso(false);
            }
            else{
                cliente.setMoroso(true);
            }
    }
    
    public Cliente findByDNI(Connection con, Cliente cliente) throws Exception{
        cliente=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        
        try{
         stmt = con.prepareStatement("SELECT * FROM Cliente WHERE DNI=?");
         stmt.setInt(1, cliente.getDNI());
         rs = stmt.executeQuery();
            
            while(rs.next()){
                cliente=new Cliente();
                obtenClienteFila(rs, cliente);
            }
         
        }catch (SQLException ex){
           ex.printStackTrace();
           throw new Exception("problema al buscar por DNI "+ex.getMessage());
        }finally
        {
            if(rs!=null) rs.close();
            if(stmt!=null) stmt.close();
        }
        return cliente;
    }
    
    public Cliente findByNick(Connection con, Cliente cliente) throws Exception{
        cliente=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        
        try{
         stmt = con.prepareStatement("SELECT * FROM Cliente WHERE Nick=?");
         stmt.setString(1, cliente.getNick());
         rs = stmt.executeQuery();
            
            while(rs.next()){
                cliente=new Cliente();
                obtenClienteFila(rs, cliente);
            }
         
        }catch (SQLException ex){
           ex.printStackTrace();
           throw new Exception("problema al buscar por Nick "+ex.getMessage());
        }finally
        {
            if(rs!=null) rs.close();
            if(stmt!=null) stmt.close();
        }
        return cliente;
    }
    
    public List<Cliente> findByNumberDNIStart(Connection con, int numero) throws Exception{
        List<Cliente> listaClientes=new ArrayList();
        
        PreparedStatement stmt=null;
        ResultSet rs=null;
        
        try{
         stmt = con.prepareStatement("SELECT * FROM Cliente WHERE DNI like ?");
         stmt.setString(1, numero+"%");
         rs = stmt.executeQuery();         
         Cliente cliente=null;
         
            while(rs.next()){
                cliente=new Cliente();
                obtenClienteFila(rs, cliente);
                listaClientes.add(cliente);
            }
         
        }catch (SQLException ex){
           ex.printStackTrace();
           throw new Exception("problema al buscar por Nick "+ex.getMessage());
        }finally
        {
            if(rs!=null) rs.close();
            if(stmt!=null) stmt.close();
        }
        return listaClientes;
    }
    
    public Cliente findByMayorGasto(Connection con) throws Exception{
        Cliente cliente=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        
        try{
         stmt = con.prepareStatement("SELECT Cliente_DNI AS DNI, (SUM(Precio*Numero))"
                 + "AS GASTO FROM articulo_factura af, articulo a, factura f"
                 + "WHERE af.Articulo_idArticulo = a.idArticulo "
                 + "AND afFactura_idFactura = f.idFactura "
                 + "GROU BY(Cliente_DNI");
         
         rs = stmt.executeQuery();
         float gatoAnterior=0;;
            
            while(rs.next()){
                float gasto=rs.getFloat("GASTO");
                if(gasto > gatoAnterior){
                    cliente=new Cliente();
                    cliente.setDNI(rs.getInt("DNI"));
                    gatoAnterior=gasto;
                }                
            }         
        }catch (SQLException ex){
           ex.printStackTrace();
           throw new Exception("problema al buscar por DNI "+ex.getMessage());
        }finally
        {
            if(rs!=null) rs.close();
            if(stmt!=null) stmt.close();
        }
        if(cliente!=null){
            cliente = findByDNI(con, cliente);
        }
        return cliente;
    }
}
