/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.SQLException;
    
        
public class Conexion_DB {
    
    public Connection abrirConecta()throws Exception{
        
            Connection con=null;
            
        try {    
            
            Class.forName("com.mysql.jdbc.Connection");
            String urlOdbc="jdbc:mysql://localhost:3306/clientesdb";
            con=(java.sql.DriverManager.getConnection(urlOdbc, "root",""));
            
            return con; 
            
        } catch (Exception e) {
            e.printStackTrace();
            
            throw new Exception("ha sido imposible establecer la conexion: " +e.getMessage());
        } 
    }
    public void cerrarConecta(Connection con)throws Exception{
        
        try{
        if(con!=null){
            con.close();            
        }
        
        } catch (SQLException e) {
            e.printStackTrace();
            
            throw new Exception("ha sido imposible cerrar la conexion: " +e.getMessage());
        } 
    }
    
}
