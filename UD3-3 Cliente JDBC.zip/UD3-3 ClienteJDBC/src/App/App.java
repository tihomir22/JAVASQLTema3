/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proytema10bd;

import DAO.Cliente_DAO;
import DAO.Conexion_DB;
import Entidad.Cliente;
import java.sql.Connection;

/**
 *
 * @author lliurex
 */
public class ProyTema10bd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        /*try {        
            Conexion_DB conexion_BD = new Conexion_DB();
            
            System.out.println("obrir connexio");
            Connection con = conexion_BD.abrirConecta();
            System.out.println("connexio oberta");

            System.out.println("tancar connexio");
            conexion_BD.cerrarConecta(con);
            System.out.println("connexio tanca");
        
         } catch (Exception ex) {           
            ex.printStackTrace(); 
         }*/        
        
        Conexion_DB conexion_BD = new Conexion_DB();    
        Connection con = null;
        try {
            con = conexion_BD.abrirConecta();  //obrim la conecxio
            Cliente_DAO cliente = new Cliente_DAO();
            
//inserir un nou client
           Cliente cliente1=new Cliente(); 
              cliente1.setDNI(1112);
              
              
              cliente1.setNombre("xx");
             /* cliente1.setApellido1("Martinez");
              cliente1.setApellido2("Martinez");
              cliente1.setNick("kkk");
              cliente1.setPassword("ale1");
              cliente1.setSaldo(1000);
              cliente1.setMoroso(false);
              
              cliente.inserta((com.mysql.jdbc.Connection) con, cliente1);
              System.out.println("nou cliente inserit");
           
           Cliente cliente2=new Cliente();
              /*cliente2.setDNI(2548);
              cliente2.setNombre("Ana");
              cliente2.setApellido1("Marti");
              cliente2.setApellido2("Marti");
              cliente2.setNick("ama");
              cliente2.setPassword("ama2");
              cliente2.setSaldo(5000);
              cliente2.setMoroso(false);
              
              cliente.inserta((com.mysql.jdbc.Connection) con, cliente2);
              System.out.println("nou cliente inserit");*/
              
//actualitzar el client anterior           
              cliente1.setApellido1("xx");
              cliente.actualiza( con, cliente1);
              System.out.println("client actualitzat"); 
              
//elimina client amb el DNI = 25
          /*Cliente cliente3=new Cliente();
              cliente3.setDNI(25);
              cliente.elimina((com.mysql.jdbc.Connection) con, cliente3);
              System.out.println("client eliminat");*/
            
        } catch (Exception ex) {           
            ex.printStackTrace();            
        }finally
        {
            conexion_BD.cerrarConecta(con); //tanquem la conexió
        }
        
        
    }
}
